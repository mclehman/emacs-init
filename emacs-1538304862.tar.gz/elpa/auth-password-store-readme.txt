Integrate Emacs' auth-source with password-store
